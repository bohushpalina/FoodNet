package foodnet.protocol;

public enum MessageType {
    GET_MENU,
    MENU,
    ORDER,
    ADDRESS,
    ORDER_SUM,
    ERROR,
    SUBMIT_ORDER
}
